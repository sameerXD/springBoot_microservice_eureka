package org.ncu.hirewheels.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "bookings")
@EntityListeners(AuditingEntityListener.class)

public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long transactionId;
	
	@Column( nullable = false)
	private String paymentMode;
	
	@Column( nullable = false)
	private String cardNumber;
	
	@Column( nullable = false)
	private Long bookingId;
	
	
	@Column( nullable = false)
	private Long upiId;


	public Long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public String getCardNumber() {
		return cardNumber;
	}


	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}


	public Long getBookingId() {
		return bookingId;
	}


	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}


	public Long getUpiId() {
		return upiId;
	}


	public void setUpiId(Long upiId) {
		this.upiId = upiId;
	}


	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", paymentMode=" + paymentMode + ", cardNumber="
				+ cardNumber + ", bookingId=" + bookingId + ", upiId=" + upiId + "]";
	}
	

	

	

}