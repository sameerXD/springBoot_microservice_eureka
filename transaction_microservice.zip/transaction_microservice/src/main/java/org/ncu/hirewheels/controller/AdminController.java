package org.ncu.hirewheels.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.ncu.hirewheels.entity.Transaction;
import org.ncu.hirewheels.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@PostMapping("/addTransaction")
	public Transaction createCategory(@RequestBody Transaction booking) {
		System.out.println(booking);
		return adminService.BookVehicle(booking);
	}
	
	@GetMapping("/getTransactions")
	public List<Transaction> getBookings() {
		return adminService.getBookings();
	}

	

}