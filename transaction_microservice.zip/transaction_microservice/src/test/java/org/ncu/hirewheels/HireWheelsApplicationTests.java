package org.ncu.hirewheels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HireWheelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
