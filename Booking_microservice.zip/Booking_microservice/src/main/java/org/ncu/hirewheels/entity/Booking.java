package org.ncu.hirewheels.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "bookings")
@EntityListeners(AuditingEntityListener.class)

public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookingId;
	
	@Column( nullable = false)
	private Date fromDate;
	
	@Column( nullable = false)
	private Date toDate;
	
	@Column( nullable = false)
	private Date bookedOn;
	
	@Column( nullable = false)
	private String aadharNumber;
	
	@Column( nullable = false)
	private Long numOfRooms;
	
	
	@Column( nullable = false)
	private Long roomNumbers;
	
	
	@Column( nullable = false)
	private Long roomPrice;
	
	@Column( nullable = false)
	private String transactionId;

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getBookedOn() {
		return bookedOn;
	}

	public void setBookedOn(Date bookedOn) {
		this.bookedOn = bookedOn;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Long getNumOfRooms() {
		return numOfRooms;
	}

	public void setNumOfRooms(Long numOfRooms) {
		this.numOfRooms = numOfRooms;
	}

	public Long getRoomNumbers() {
		return roomNumbers;
	}

	public void setRoomNumbers(Long roomNumbers) {
		this.roomNumbers = roomNumbers;
	}

	public Long getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(Long roomPrice) {
		this.roomPrice = roomPrice;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", fromDate=" + fromDate + ", toDate=" + toDate + ", bookedOn="
				+ bookedOn + ", aadharNumber=" + aadharNumber + ", numOfRooms=" + numOfRooms + ", roomNumbers="
				+ roomNumbers + ", roomPrice=" + roomPrice + ", transactionId=" + transactionId + "]";
	}

	

}