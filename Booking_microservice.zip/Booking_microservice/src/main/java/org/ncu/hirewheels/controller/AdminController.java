package org.ncu.hirewheels.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.ncu.hirewheels.entity.Booking;
import org.ncu.hirewheels.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@PostMapping("/addBooking")
	public Booking createCategory(@RequestBody Booking booking) {
		Booking bkObject =  adminService.BookVehicle(booking);
		
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
        Map map = new HashMap<String, String>();
        map.put("Content-Type", "application/json");

        headers.setAll(map);

        Map req_payload = new HashMap();
        req_payload.put("paymentMode", "UPI");
        req_payload.put("cardNumber", "12312341");
        req_payload.put("bookingId", bkObject.getBookingId());
        req_payload.put("upiId", "42342");
        
        HttpEntity<?> request = new HttpEntity<>(req_payload, headers);
        String url = "http://localhost:8081/api/admin/addTransaction";

        ResponseEntity<?> response = new RestTemplate().postForEntity(url, request, String.class);
        Object entityResponse =  response.getBody();
        System.out.println(entityResponse);
        
		
		return bkObject;
	}
	
	@GetMapping("/getBookings")
	public List<Booking> getBookings() {
		return adminService.getBookings();
	}

	

}